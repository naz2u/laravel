


<div >
    <a href="<?php echo e(route('student.create')); ?>"><button class="btn btn-primary"> Add New</button></a>
</div><br></br>
<div class="col-md-12">
	<p align="center">All Student</p>
    <div class="table-responsive">

        <table class="table table-bordered table-condensed table-striped" border="1" align="center">

            <thead>
                <th>#</th>
                <th>NAME</th>
                <th>CLASS</th>
                <th>ROLL</th>
                <th colspan="3"  style="width: 150px">ACTION</th>
            </thead>

            <tbody>
                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>

                    <td><?php echo e($row->id); ?></td>
                    <td><?php echo e($row->name); ?></td>
                    <td><?php echo e($row->class); ?></td>
                    <td><?php echo e($row->roll); ?></td>

                    <td>
                        <a href="<?php echo e(route('student.show', $row->id)); ?>" class="btn btn-primary">Details</a>

                    </td>

                    <td>
                        <a href="<?php echo e(route('student.edit', $row->id)); ?>" class="btn btn-primary">Edit</a>

                    </td>
                    <td>
                        <form action="<?php echo e(route('student.destroy', $row->id)); ?>"  method="post">
                            <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                            <button style="width: 70px;" class="btn btn-danger"  type="submit">Delete</button>
                        </form>
                    </td>

                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>

        </table>
    </div>
    <div>
       
    </div>
</div>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\laraveblog\resources\views/student/student.blade.php ENDPATH**/ ?>