<ul>
	<?php $__currentLoopData = $user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $users): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	<li><?php echo e($users->name); ?> - <?php echo e($users->profile->telephone); ?></li>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</ul><?php /**PATH D:\xampp\htdocs\laraveblog\resources\views/test.blade.php ENDPATH**/ ?>