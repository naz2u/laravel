
<div >
    <a href="<?php echo e(route('product/create')); ?>"><button class="btn btn-primary">Add New</button></a>
</div><br></br>

<?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<p>
	<?php echo e($category->name); ?>

	<ol>
		<?php $__currentLoopData = $category->product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<li><?php echo e($product->title); ?></b> - <?php echo e($product->description); ?>


			<img width="40px"  src="images/upload/<?php echo e($product->picture); ?>">

		</li>


		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	</ol>
</p>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php /**PATH D:\xampp\htdocs\laraveblog\resources\views/product/index.blade.php ENDPATH**/ ?>