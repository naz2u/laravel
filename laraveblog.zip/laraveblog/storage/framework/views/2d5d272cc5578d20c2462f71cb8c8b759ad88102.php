<form action="<?php echo e(route('product/store')); ?>" method="POST" enctype="multipart/form-data">
    <?php echo csrf_field(); ?>

     <div class="row">

        <div class="col-xs-12 col-sm-12 col-md-12">
            <div class="form-group">
                 <strong>Category:</strong>
                 <select name="category_id">

                    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                        <option value="<?php echo e($category->id); ?>"><?php echo e($category->name); ?></option>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    
                </select>
                
            </div><br>
        </div>

        <div class="col-xs-12 col-sm-12 col-md-12">
            <div class="form-group">
                <strong>Title:</strong>
                <input type="text" name="title" class="form-control" placeholder="title">
            </div>
        </div><br>
          	 <?php echo csrf_field(); ?>

        <div class="col-xs-12 col-sm-12 col-md-12">
            <div class="form-group">
                <strong>Description:</strong>
                <textarea type="text" name="description" class="form-control" placeholder="description"></textarea>
            </div>
        </div><br>

         <div class="col-xs-12 col-sm-12 col-md-12">
            <div class="form-group">
                <strong>Picture:</strong>
                <input type="file" name="picture" class="form-control" placeholder="picture">
            </div>
        </div><br>
        
        <div class="col-xs-12 col-sm-12 col-md-12 text-center">
                <button type="submit" class="btn btn-primary">Submit</button>
        </div>
    </div>
</form><?php /**PATH D:\xampp\htdocs\laraveblog\resources\views/product/create.blade.php ENDPATH**/ ?>