<?php


use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

Route::get('test','App\Http\Controllers\TestController@index');
Route::get('home/data','App\Http\Controllers\TestController@data');
Route::get('web-development-tutorial','App\Http\Controllers\TestController@about');


Route::resource('contacts','App\Http\Controllers\ContactController');

Route::resource('student','App\Http\Controllers\StudentController');

Route::resource('driver','App\Http\Controllers\DriverController');

Route::resource('test','App\Http\Controllers\TestController');

Route::resource('product','App\Http\Controllers\ProductController');

Route::get('product/create','App\Http\Controllers\ProductController@create')->name('product/create');
Route::post('product/store','App\Http\Controllers\ProductController@store')->name('product/store');


Route::resource('category','App\Http\Controllers\ProductController');








