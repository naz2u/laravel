<ul>
	@foreach($user as $users)
	<li>{{$users->name}} - {{$users->profile->telephone}}</li>
	@endforeach
</ul>