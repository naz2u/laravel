@extends('layouts.app')
@section('content')

@if ($message = Session::get('success'))
        <div class="alert alert-success">
            <p>{{ $message }}</p>
        </div>
    @endif



<div >
    <a href="{{route('contacts.create')}}"><button class="btn btn-primary"> Add New</button></a>
</div><br></br>
<div class="col-md-12">

    <div class="table-responsive">
        <table class="table table-bordered table-condensed table-striped" border="1" align="center">
            <thead>

                <th>ID</th>
                <th>NAME</th>
                <th>EMAIL</th>
                <th>PHONE</th>
                <th colspan="3"  style="width: 150px">ACTION</th>
            </thead>

            <tbody>
                @foreach($data as $row)
                <tr>

                    <td>{{$row->id }}</td>
                    <td>{{$row->name }}</td>
                    <td>{{$row->email }}</td>
                    <td>{{$row->phone }}</td>

                    <td>
                        <a href="{{ route('contacts.show', $row->id)}}" class="btn btn-primary">Details</a>

                    </td>

                    <td>
                        <a href="{{ route('contacts.edit', $row->id)}}" class="btn btn-primary">Edit</a>

                    </td>
                    <td>
                        <form action="{{ route('contacts.destroy', $row->id)}}"  method="post">
                            @csrf @method('DELETE')
                            <button style="width: 70px;" class="btn btn-danger"  type="submit">Delete</button>
                        </form>
                    </td>

                </tr>
                @endforeach
            </tbody>

        </table>
    </div>
    <div>
        <?php echo $data->render(); ?>
    </div>
</div>

@endsection