<form action="{{ route('product/store') }}" method="POST" enctype="multipart/form-data">
    @csrf

     <div class="row">

        <div class="col-xs-12 col-sm-12 col-md-12">
            <div class="form-group">
                 <strong>Category:</strong>
                 <select name="category_id">

                    @foreach($data as $category)

                        <option value="{{$category->id}}">{{$category->name}}</option>

                    @endforeach
                    
                </select>
                
            </div><br>
        </div>

        <div class="col-xs-12 col-sm-12 col-md-12">
            <div class="form-group">
                <strong>Title:</strong>
                <input type="text" name="title" class="form-control" placeholder="title">
            </div>
        </div><br>
          	 @csrf

        <div class="col-xs-12 col-sm-12 col-md-12">
            <div class="form-group">
                <strong>Description:</strong>
                <textarea type="text" name="description" class="form-control" placeholder="description"></textarea>
            </div>
        </div><br>

         <div class="col-xs-12 col-sm-12 col-md-12">
            <div class="form-group">
                <strong>Picture:</strong>
                <input type="file" name="picture" class="form-control" placeholder="picture">
            </div>
        </div><br>
        
        <div class="col-xs-12 col-sm-12 col-md-12 text-center">
                <button type="submit" class="btn btn-primary">Submit</button>
        </div>
    </div>
</form>