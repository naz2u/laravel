
<div >
    <a href="{{route('product/create')}}"><button class="btn btn-primary">Add New</button></a>
</div><br></br>

@foreach($data as $category)
<p>
	{{$category->name}}
	<ol>
		@foreach($category->product as $product)
		<li>{{$product->title}}</b> - {{$product->description}}

			<img width="40px"  src="images/upload/{{$product->picture}}">

		</li>


		@endforeach
	</ol>
</p>
@endforeach

