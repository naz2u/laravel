
@extends('layouts.app')
@if ($errors->any())
    <div class="alert alert-danger">
        <strong>Whoops!</strong> There were some problems with your input.<br><br>
        <ul>
            @foreach ($errors->all() as $error)
                <li>{{ $error }}</li>
            @endforeach
        </ul>
    </div>
 @endif
​
​
<form action="{{ route('student.update', $data->id) }}" method="POST">
        @csrf
        @method('PUT')
​
​
     <div class="row">
​
        <div class="col-xs-12 col-sm-12 col-md-12">
            <div class="form-group">
                <strong>Name:</strong>
                <input type="text" value="{{$data->name}}" name="name" class="form-control" placeholder="Name">
            </div>
        </div>   
        <div class="col-xs-12 col-sm-12 col-md-12">
            <div class="form-group">
                <strong>Class:</strong>
                <input type="text" name="class" value="{{$data->class}}" class="form-control" placeholder="class">
            </div>
        </div>        
        <div class="col-xs-12 col-sm-12 col-md-12">
            <div class="form-group">
                <strong>Roll:</strong>
                <input type="text" name="roll" value="{{$data->roll}}" class="form-control" placeholder="roll">
            </div>
        </div>
​
        <div class="col-xs-12 col-sm-12 col-md-12 text-center">
                <button type="submit" class="btn btn-primary">Update</button>
        </div>
    </div>
   
</form>