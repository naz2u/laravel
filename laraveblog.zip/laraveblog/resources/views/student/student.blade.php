
@extends('layouts.app')

<div >
    <a href="{{route('student.create')}}"><button class="btn btn-primary"> Add New</button></a>
</div><br></br>
<div class="col-md-12">
	<p align="center">All Student</p>
    <div class="table-responsive">

        <table class="table table-bordered table-condensed table-striped" border="1" align="center">

            <thead>
                <th>#</th>
                <th>NAME</th>
                <th>CLASS</th>
                <th>ROLL</th>
                <th colspan="3"  style="width: 150px">ACTION</th>
            </thead>

            <tbody>
                @foreach($data as $row)
                <tr>

                    <td>{{$row->id }}</td>
                    <td>{{$row->name }}</td>
                    <td>{{$row->class }}</td>
                    <td>{{$row->roll }}</td>

                    <td>
                        <a href="{{ route('student.show', $row->id)}}" class="btn btn-primary">Details</a>

                    </td>

                    <td>
                        <a href="{{ route('student.edit', $row->id)}}" class="btn btn-primary">Edit</a>

                    </td>
                    <td>
                        <form action="{{ route('student.destroy', $row->id)}}"  method="post">
                            @csrf @method('DELETE')
                            <button style="width: 70px;" class="btn btn-danger"  type="submit">Delete</button>
                        </form>
                    </td>

                </tr>
                @endforeach
            </tbody>

        </table>
    </div>
    <div>
       
    </div>
</div>
