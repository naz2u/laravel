<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class profile extends Model
{
    use HasFactory;

     $table->increments('id');
	 $table->integer('user_id')->unsigned()->nullable();
	 $table->foreign('user_id')->references('id')->on('users');
	 $table->string('name');
	 $table->string('telephone');
	 $table->timestamps();
}
