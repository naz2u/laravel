<?php

namespace App\Http\Controllers;

use App\Models\Driver;
use Illuminate\Http\Request;

class DriverController extends Controller
{
    
   public function index(){

   		$data=Driver::orderBy('id','asc')->paginate(10)->setPath('drivers');
   		return view('driver.driver',compact(['data']));
   }

    public function create()
    {

        return view('driver.create');
    }

    public function store(Request $request)
    {
        $request->validate([
         'name' => 'required',
         'email' => 'required',
         'address' => 'required',
         'phone' => 'required'
        ]);

        Driver::create($request->all());
        return redirect('driver');
    }

     public function show($id)
    {
       $data =  Driver::find($id);
       return view('driver.show',compact(['data']));
    }


     public function edit($id)
    {
       $data = Driver::find($id);
       return view('driver.edit',compact(['data']));
    }

   public function update(Request $request, Driver $driver)
    {
        $request->validate([
             'name' => 'required',
	         'email' => 'required',
	         'address' => 'required',
	         'phone' => 'required'
        ]);

        $driver->update($request->all());

        return redirect('driver');
    }


    public function destroy($id)
    {
        Driver::where('id',$id)->delete();
        return redirect()->back()->with('success','Delete Successfully');
    }
}
