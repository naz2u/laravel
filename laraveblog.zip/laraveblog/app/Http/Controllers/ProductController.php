<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Product;
use App\Models\Category;

class ProductController extends Controller
{
   public function index(){
   	$data = Category::all();
   	return view('product.index',compact(['data']));
   }

   public function category(){

   	echo $data =Product::find(2)->category->name;
   }

   public function create(){

   		$data = Category::all();

   		return view('product.create',compact(['data']));

   }

   public function store(Request $request){

   		$request->validate(

   			[
   				'category_id'=>'required',
   				'title'=>'required',
   				'description'=>'required',
   				'picture'=>'required|file|mimes:jpg,jpeg,png',
   			]);

   		$fileName = time().'.'.$request->picture->extension();

        $request->picture->move(public_path('images/upload'), $fileName);
        
 		$input = $request->all();

		$input['picture'] = $fileName;

   		 //product::create($request->all());
		Product::create($input);
        return redirect('product');
   }
}
