<?php

namespace App\Http\Controllers;

use App\Models\Student;
use Illuminate\Http\Request;

class StudentController extends Controller
{
   public function index(){

   		$data=Student::orderBy('id','asc')->paginate(10)->setPath('students');
   		return view('student.student',compact(['data']));
   }

    public function create()
    {

        return view('student.create');
    }

    public function store(Request $request)
    {
        $request->validate([
         'name' => 'required',
         'class' => 'required',
         'roll' => 'required'
        ]);

        student::create($request->all());
        return redirect('student');
    }


    public function show($id)
    {
       $data =  Student::find($id);
       return view('student.show',compact(['data']));
    }


     public function edit($id)
    {
       $data = Student::find($id);
       return view('student.edit',compact(['data']));
    }

   public function update(Request $request, Student $student)
    {
        $request->validate([
            'name' => 'required',
            'class' => 'required',
            'roll' => 'required'
        ]);

        $student->update($request->all());

        return redirect('student');
    }


    public function destroy($id)
    {
        Student::where('id',$id)->delete();
        return redirect()->back()->with('success','Delete Successfully');
    }

}
